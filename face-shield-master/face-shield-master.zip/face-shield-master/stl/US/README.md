# US versions of the files

**WARNING: THIS FOLDER CONTAINS US VERSION WITH NON-METRIC DIMENSIONS!**

If the version you need is not in this folder, I don't have a US version yet. Feel free to open an issue if you are missing something.
